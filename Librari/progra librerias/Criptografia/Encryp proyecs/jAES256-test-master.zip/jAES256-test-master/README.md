jAES256-test
============

Prueba de encriptación AES 256 en Java.

Para poder testear se debe agregar Java Policy.
